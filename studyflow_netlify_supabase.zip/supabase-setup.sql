-- Run this entire script once in Supabase Dashboard > SQL Editor.
create table if not exists public.student_assignments (
  user_id uuid primary key references auth.users(id) on delete cascade,
  assignments jsonb not null default '[]'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.student_assignments enable row level security;

-- Each signed-in student can read only their own row.
create policy "Students can read their own assignments"
on public.student_assignments
for select
to authenticated
using (auth.uid() = user_id);

-- Each signed-in student can create only their own row.
create policy "Students can insert their own assignments"
on public.student_assignments
for insert
to authenticated
with check (auth.uid() = user_id);

-- Each signed-in student can update only their own row.
create policy "Students can update their own assignments"
on public.student_assignments
for update
to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

grant select, insert, update on public.student_assignments to authenticated;
