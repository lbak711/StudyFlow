STUDYFLOW — NETLIFY + SUPABASE (iPHONE SETUP)

WHAT THIS PACKAGE DOES
- Keeps the same StudyFlow My Plan, My Homework, and Calendar screens.
- Uses Supabase email/password accounts.
- Saves each student's homework in a private Supabase database row.
- Syncs homework when the student signs in on another device.
- Keeps a local browser copy too.

FILES
- index.html: the app
- supabase.js: sign-in and cloud-sync code
- supabase-config.js: the two public Supabase project values you add
- supabase-setup.sql: database table and privacy rules

PART 1 — CREATE THE SUPABASE BACKEND
1. In Safari, go to https://supabase.com and create a free account.
2. Create a new project. Give it a name such as StudyFlow. Choose a strong database password and save it somewhere private. Do not put that password in the app.
3. Wait for the project to finish setting up.
4. In the Supabase project, open SQL Editor, create a new query, and paste all of supabase-setup.sql. Run it once.
5. Open Project Settings > API Keys (or Connect, depending on the dashboard layout).
6. Copy the Project URL and the Publishable key. If the dashboard only shows the older anon key, that can be used instead. NEVER copy the secret key or service_role key into the website.

PART 2 — ADD YOUR SUPABASE DETAILS TO THE APP
1. Open supabase-config.js in a text editor.
2. Replace PASTE_YOUR_SUPABASE_PROJECT_URL_HERE with your Project URL.
3. Replace PASTE_YOUR_SUPABASE_PUBLISHABLE_KEY_HERE with your Publishable key (or legacy anon key).
4. Save the file. Keep the quotation marks around both values.

PART 3 — PUT THE APP ON NETLIFY FROM YOUR iPHONE
Recommended route: GitHub repository connected to Netlify.
1. In Safari, create or sign in to a GitHub account.
2. Create a new repository named studyflow. Private is fine.
3. Use the repository's Add file / Upload files option to upload these four files at the repository's top level: index.html, supabase.js, supabase-config.js, and (optionally) supabase-setup.sql. You do not need to upload this README.
4. Open Netlify in Safari and sign in.
5. Choose Add new project / Import an existing project, select GitHub, and authorize the repository.
6. Select the studyflow repository. For a plain HTML app, set Build command to blank and Publish directory to . (a single period). Deploy.
7. When Netlify finishes, open the site URL it gives you.

PART 4 — TEST IT
1. Open your Netlify website.
2. Tap Sign in / Create account and create a test account using an email you can access.
3. If email confirmation is enabled, open the confirmation email and follow its link. Return to the StudyFlow website and sign in.
4. Add a test homework assignment.
5. Open the same website in another browser or device, sign in with the same account, and check that the assignment appears.
6. Test with a second, different account. It should NOT see the first account's homework.

IMPORTANT NOTES
- Supabase Free currently includes 50,000 monthly active users and a 500 MB database, but free projects can pause after one week of inactivity. Check the current pricing page before launching to a large group: https://supabase.com/pricing
- Netlify hosting also has its own free-plan limits. $0 is possible for a small project, not guaranteed at any scale.
- The app currently syncs homework assignments. The available-minutes and selected-plan-date preferences remain stored locally on each device.
- Existing homework on a device is copied into a new account only if that account has no cloud homework yet. If the account already has cloud homework, the cloud copy replaces the local list.
- The Publishable key (or legacy anon key) is designed for browser use ONLY because the database has Row Level Security policies. Never put a Supabase secret key or service_role key in this file.
- Do not collect student full names, school IDs, grades, or other unnecessary personal information. Before inviting minors or using this at a school, have a parent/guardian and the school review privacy, consent, and applicable student-data requirements.

TROUBLESHOOTING
- If sign-in says email not confirmed, check the email inbox and spam folder, confirm the account, then sign in again.
- If the app says the table is missing, run supabase-setup.sql in Supabase SQL Editor.
- If you see an API permission error, confirm the SQL script ran fully and that Row Level Security is enabled on public.student_assignments.
- If the app says to add Supabase details, check that supabase-config.js contains the correct Project URL and Publishable key and redeploy the site.
